﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double it1;
            double it2;
            double it3;
            double it4;
            double it5;
            double valor;
            double troco;

            Console.WriteLine("Digite o valor do primeiro item: ");
            it1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do segundo item: ");
            it2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do terceiro item: ");
            it3 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do quarto item: ");
            it4 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do quinto item: ");
            it5 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do pagamento: ");
            valor = double.Parse(Console.ReadLine());

            troco = valor - (it1 + it2 + it3 + it4 + it5);

            Console.WriteLine("O troco a ser devolvido é {0} reais", troco);
        }
    }
}
