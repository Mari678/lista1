﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x;
            double y;
            double resultado;

            Console.WriteLine("Digite o valor de x: ");
            x = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor de y: ");
            y = double.Parse(Console.ReadLine());

            resultado = Math.Pow(x, y);

            Console.WriteLine("{0} elevado a {1} é igual a {2}", x, y, resultado);
        }
    }
}
