﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cotacao;
            double quantidade;
            double resultado;

            Console.WriteLine("Digite a cotaçao do dólar: ");
            cotacao = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite a quantidade de dólares: ");
            quantidade = double.Parse(Console.ReadLine());

            resultado = cotacao * quantidade;

            Console.WriteLine("{0} dólares com a cotaçao do dólar em {1} equivale a {2} reais", quantidade, cotacao, resultado);
        }
    }
}
