﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double numero1;
            double numero2;
            double numero3;
            double numero4;
            double resultado;

            Console.WriteLine("Digite o primeiro valor: ");
            numero1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o segundo valor: ");
            numero2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o terceiro valor: ");
            numero3 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o quarto valor: ");
            numero4 = double.Parse(Console.ReadLine());

            resultado = (numero1 + numero2 + numero3 + numero4) / 4;

            Console.WriteLine("A média aritmética dos valores {0}, {1}, {2} e {3} é {4}", numero1, numero2, numero3, numero4, resultado);
        }
    }
}
