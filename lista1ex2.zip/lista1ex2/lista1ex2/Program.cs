﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta;
            double resultado;

            Console.Write("Digite o valor da aresta: ");
            aresta = double.Parse(Console.ReadLine());

            resultado = aresta * aresta;

            Console.WriteLine("A área do quadrado com aresta {0} é {1}", aresta, resultado);
        }
    }
}
