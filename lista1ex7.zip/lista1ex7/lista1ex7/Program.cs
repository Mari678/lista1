﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double milhas;
            double kms;

            Console.Write("Digite a quantidade de milhas maritmas: ");
            milhas = double.Parse(Console.ReadLine());

            kms = milhas * 1.852;

            Console.WriteLine("{0} milhas maritimas equivalem a {1} quilômetros", milhas, kms);
        }
    }
}
