﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val1;
            double val2;
            double resultado;

            Console.Write("Digite o 1º valor: ");
            val1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 2º valor: ");
            val2 = double.Parse(Console.ReadLine());

            resultado = Math.Sqrt(val1 * val2);

            Console.WriteLine("A média geométrica dos valores {0} e {1} é {2}", val1, val2, resultado);
        }
    }
}
