﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double celsius;
            double resultado;

            Console.Write("Digite o valor em °C: ");
            celsius = double.Parse(Console.ReadLine());

            resultado = celsius * 1.8 + 32;

            Console.WriteLine("{0}°C equivalem a {1}°F", celsius, resultado);
        }
    }
}
