﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diagonal;
            double resultado;

            Console.WriteLine("Digite o valor da diagonal: ");
            diagonal = double.Parse(Console.ReadLine());

            resultado = (diagonal * diagonal) / 2;

            Console.WriteLine("A área o quadrado com diagonal {0} é {1}", diagonal, resultado);
        }
    }
}
