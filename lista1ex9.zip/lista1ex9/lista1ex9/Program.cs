﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diametro;
            double resultado;

            Console.WriteLine("Digite o valor do diametro: ");
            diametro = double.Parse(Console.ReadLine());

            resultado = 3.14 * ((diametro / 2) * (diametro / 2));

            Console.WriteLine("A circunferencia com {0} de diametro possui {1} de area", diametro, resultado);
        }
    }
}
