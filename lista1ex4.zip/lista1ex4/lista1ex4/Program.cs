﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista1ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1;
            double altura;
            double area;

            Console.WriteLine("Digite o valor da base: ");
            base1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da altura: ");
            altura = double.Parse(Console.ReadLine());

            area = (base1 * altura) / 2;

            Console.WriteLine("A área do triângulo com base {0} e altura {1} é {2}", base1, altura, area);
        }
    }
}
